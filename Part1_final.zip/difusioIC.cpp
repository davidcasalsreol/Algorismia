#include <iostream>
#include <vector>
#include "graf.h"
#include <queue>
#include <set>
#include <unordered_set>
#include <chrono>
#include <ctime>
using namespace std;


pair<queue<int>,int> difusioIC(Graf G, double p, set<int> &Activats){
    srand(time(0));
    set<int> ActivatsTotals = Activats; //Aquesta implementació visita els vertex activats ordenats creixentment per id de node
    //unordered_set<int> ActivatsTotals = Activitats ho per FIFO
    //queue<int> ActivatsTotals = Activat5s ho fa per FIFO pero no tenim la opcio de cridar a .find() com si ho podem fer a les altres
    queue<int> rta;
    while(Activats.size() > 0 and ActivatsTotals.size() < G.nNodes()){
        auto it = Activats.begin();
        rta.push(*it);
        //cout << "analitzemmm " << *it << endl;
        int node = *it ;
        Activats.erase(it);
        vector<int> adj = G.nodesadjacents(node);
        for(int i = 0; i < adj.size(); ++i){
            cout << adj[i] << endl;
          //  cout <<"posicio de activada " << *ActivatsTotals.find(adj[i]) << " sobre " << *ActivatsTotals.end() << endl;
            if(ActivatsTotals.find(adj[i]) == ActivatsTotals.end()) {
                double r = (double)rand()/ (double)RAND_MAX;
            //    cout << "amb probabilitat de " << r << endl;
              //  cout << r << endl;
                if(r < p){
                //    cout << "activo " << adj[i]<< endl;
                    Activats.insert(adj[i]);
                    ActivatsTotals.insert(adj[i]);
                    
                }
            }
        }
        
    }
    return make_pair(rta,ActivatsTotals.size());
}

int tamany(Graf G, double p, set<int> &Activats)  {
    return difusioIC(G,p,Activats).first.size();
}


int main(){
    Graf G;
    Node N;
    
    cout << endl;
    set<int> conjIni;
    cout << "probabilitat entre 0 i 1:" << endl;
    double p;
    cin >> p;
    cout << "dona'm un conjunt inicial de nodes activats" << endl;
    int n;
    while (cin >> n && n != -1) {
        conjIni.insert(n);
        }
    cout << "tamany de: " <<conjIni.size() << endl;
    auto start_time = chrono::high_resolution_clock::now();
    pair<queue<int>,int> solLT = difusioIC(G,p,conjIni);
    auto end_time = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::milliseconds>(end_time - start_time);

    cout << "Temps d'execució: " << duration.count() << " ms\n";
    cout << "Nombre de vèrtexs activats: " << solLT.second << endl;
    cout << "començo" << endl;
    while (solLT.first.size() != 0) {
        int node = solLT.first.front();
        cout <<node <<  ' ';
        solLT.first.pop();
    }
    cout << endl;
    cout << "acabat" << endl;
    cout << endl;
}