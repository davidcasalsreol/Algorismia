#include <iostream>
#include <vector>
#include "graf.h"
#include <queue>
#include <set>
#include <unordered_set>
#include <chrono>

using namespace std;


pair<queue<int>,int> difusioLT(Graf G, double r, set<int> &Activats){
    set<int> ActivatsTotals = Activats;
    queue<int> rta;
    vector<int> InfluenciaNodes(G.nNodes(), 0);
    while(Activats.size() > 0 and ActivatsTotals.size() < G.nNodes()){
        auto it = Activats.begin();
        rta.push(*it);
        //cout << "analitzemmm " << *it << endl;
        int node = *it ;
        Activats.erase(it);        
        if(G.esValid(node)){
          //  cout << "valid" << endl;
            vector<int> adj = G.nodesadjacents(node);
            for(int i = 0; i < adj.size(); ++i){
                int g  = G.grauNode(adj[i]);
                if(ActivatsTotals.find(adj[i]) == ActivatsTotals.end()) {   
            //        cout << adj[i] << " amb grau "<< g<<", tenim " << InfluenciaNodes[adj[i]]  << " i necessitem " <<r*g << endl;
                    InfluenciaNodes[adj[i]]++;
                    if(InfluenciaNodes[adj[i]] >= r*g){
              //          cout << adj[i] << " ha superat el seu llindar " << r*g << endl;
                        Activats.insert(adj[i]);
                        ActivatsTotals.insert(adj[i]);
                    }
                }
            }
        }
    }
    return make_pair(rta,ActivatsTotals.size());
}

int main(){
    Graf G;
    Node N;
     cout << endl;
    set<int> conjIni;
    cout << "probabilitat entre 0 i 1:" << endl;
    double p;
    cin >> p;
    cout << "dona'm un conjunt inicial de nodes activats" << endl;
    int n;
    while (cin >> n && n != -1) {
        conjIni.insert(n);
        cout << "de moment: " <<conjIni.size();
        }
    auto start_time = chrono::high_resolution_clock::now();
    pair<queue<int>,int> solLT = difusioLT(G,0.4,conjIni);
    auto end_time = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::milliseconds>(end_time - start_time);

    cout << "Temps d'execució: " << duration.count() << " ms\n";
    cout << "Nombre de vèrtexs activats: " << solLT.second << endl;
    cout << "començo" << endl;
    while (solLT.first.size() != 0) {
        int node = solLT.first.front();
        cout <<node <<  ' ';
        solLT.first.pop();
    }
    cout << endl;
    cout << "acabat" << endl;
}