#include <iostream>
#include <vector>
#include <string>
#include "graf.h"
using namespace std;

//vector<Node> nodes;
//int nombrenodes;

//Constructora amb paràmetre.
Graf::Graf(vector<Node> nodesEnt){
    nodes = nodesEnt;
    nombrenodes = nodesEnt.size();
}

Graf::Graf(bool b){
    nodes = vector<Node> (0);
    nombrenodes = 0;
}
//Constructora buida (per introduir el graf, no permetrem graf buit)
Graf::Graf(){
    cout << "nombre i titol:" << endl;
    string nom, s;
    cin >> nom >> s;
    cout << "nombre vertex i arestes:" << endl;
    int n, m;
    cin >> n >> m;
    nombrenodes = n;
    vector<Node> nodesEntrada(n);
    for (int i = 0; i < m; ++i) {
        char c;
        cin >> c;
        int u, v;
        cin >> u >> v;

        pair<int,bool> uu ;
        pair<int,bool> vv ;

        uu.first = v;
        uu.second = true;
        vv.first = u;
        vv.second = true;

        nodesEntrada[u].adjacents.push_back(uu);
        nodesEntrada[v].adjacents.push_back(vv);
        
    }
    nodes = nodesEntrada;
    nombrenodes = nodesEntrada.size();
}

void Graf::afegirNode(Node n){
    nodes.push_back(n);
    for(int i = 0; i < n.adjacents.size(); ++i){
        if (n.adjacents[i].second){
            nodes[n.adjacents[i].first].adjacents.push_back(make_pair(n.id, true));
        }
    }
    nombrenodes++;
}

void Graf::eliminarNode(int id){
    nodes[id].valid = false;
    for(int i = 0; i < nodes[id].adjacents.size(); ++i){
        nodes[id].adjacents[i].second = false;
        //False totes les arestes que tinguin al node ID. Primer busquem dintre del node al que és adj.
        int nodeadj = nodes[id].adjacents[i].first;
        for(int j = 0; j < nodes[nodeadj].adjacents.size(); ++j){
            if( nodes[nodeadj].adjacents[j].first == id)  nodes[nodeadj].adjacents[j].second = false;
        } 
    }
    nombrenodes--;
}

//Consultores
int Graf::nNodes(){
    return nombrenodes;
}

vector<int> Graf::nodesadjacents(int nodeID){
    vector<int> ret;
    if (nodeID > nodes.size()) return ret;
    vector<pair<int, bool>> n = nodes[nodeID].adjacents;
    for (int i = 0; i < n.size(); ++i){
        if(n[i].second) ret.push_back(n[i].first);
    }
    return ret;
}

bool Graf::esValid(int n){
    return nodes[n].valid;
}

int Graf::grauNode(int n){
    int r = 0;
    for(int i = 0; i < nodes[n].adjacents.size(); ++i){
        if(nodes[n].adjacents[i].second) ++r; //Hem de tenir en compte que no totes les arestes son vàlides.
    }
    return r;
}
